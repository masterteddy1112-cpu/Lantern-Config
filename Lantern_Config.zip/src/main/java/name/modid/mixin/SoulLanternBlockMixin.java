package name.modid.mixin;

import name.modid.blockentity.LanternBlockEntity;
import name.modid.blockentity.ModBlockEntities;
import net.minecraft.block.BlockState;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LanternBlock.class)
public class SoulLanternBlockMixin {

    @Inject(method = "createBlockEntity", at = @At("RETURN"), cancellable = true)
    private void injectBlockEntity(BlockPos pos, BlockState state, CallbackInfoReturnable<BlockEntity> cir) {
        cir.setReturnValue(new LanternBlockEntity(pos, state));
    }

    @Inject(method = "getTicker", at = @At("RETURN"), cancellable = true)
    private <T extends BlockEntity> void injectTicker(
            World world, BlockState state, BlockEntityType<T> type,
            CallbackInfoReturnable<BlockEntityTicker<T>> cir) {
        if (type == ModBlockEntities.LANTERN_BLOCK_ENTITY) {
            cir.setReturnValue((tickWorld, pos, tickState, blockEntity) -> {
                if (blockEntity instanceof LanternBlockEntity lanternBE) {
                    lanternBE.tick();
                }
            });
        }
    }
}