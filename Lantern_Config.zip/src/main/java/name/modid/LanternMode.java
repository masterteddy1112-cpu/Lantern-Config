package name.modid;

public enum LanternMode {
    REGULAR,
    RANDOM_FLICKER,
    FUSED;

    public static LanternMode fromIndex(int index) {
        return values()[index % values().length];
    }
}
