package name.modid.blockentity;

import name.modid.LanternMode;
import name.modid.LanternConfig;
import name.modid.screen.LanternScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public class LanternBlockEntity extends BlockEntity implements ExtendedScreenHandlerFactory {

    private LanternMode mode = LanternMode.REGULAR;
    private int flickerTimer = 0;
    private boolean flickerOn = true;
    private int fuseTimer = 0;
    private boolean fused = false;
    private int fuseDuration = 0;

    public LanternBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LANTERN_BLOCK_ENTITY, pos, state);
    }

    public LanternMode getMode() { return mode; }

    public void setMode(LanternMode mode) {
        this.mode = mode;
        this.flickerTimer = 0;
        this.flickerOn = true;
        this.fuseTimer = 0;
        this.fused = false;
        this.fuseDuration = randomFuseDuration();
        markDirty();
        if (world != null && !world.isClient()) {
            world.updateListeners(pos, getCachedState(), getCachedState(), 3);
        }
    }

    public boolean isLitOverride() {
        if (mode == LanternMode.RANDOM_FLICKER) return flickerOn;
        if (mode == LanternMode.FUSED) return !fused;
        return true; // REGULAR
    }

    public void tick() {
        if (world == null || world.isClient()) return;
        switch (mode) {
            case RANDOM_FLICKER -> handleFlicker();
            case FUSED -> handleFuse();
            default -> {}
        }
    }

    private void handleFlicker() {
        flickerTimer++;
        int interval = 20 + world.random.nextInt(60);
        if (flickerTimer >= interval) {
            flickerTimer = 0;
            flickerOn = !flickerOn;
            if (!flickerOn) {
                flickerTimer = -world.random.nextInt(8) - 1;
            }
            world.updateListeners(pos, getCachedState(), getCachedState(), 3);
            markDirty();
        }
    }

    private void handleFuse() {
        if (fused) return;
        fuseTimer++;
        if (fuseTimer >= fuseDuration) {
            fused = true;
            world.updateListeners(pos, getCachedState(), getCachedState(), 3);
            markDirty();
            LanternConfig.LOGGER.info("Lantern at {} has fused out.", pos.toShortString());
        }
    }

    private int randomFuseDuration() {
        return 600 + (world != null ? world.random.nextInt(3000) : 1200);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        String modeName = nbt.getString("LanternMode");
        try {
            mode = LanternMode.valueOf(modeName);
        } catch (IllegalArgumentException e) {
            mode = LanternMode.REGULAR;
        }
        flickerOn = nbt.getBoolean("FlickerOn");
        flickerTimer = nbt.getInt("FlickerTimer");
        fused = nbt.getBoolean("Fused");
        fuseTimer = nbt.getInt("FuseTimer");
        fuseDuration = nbt.getInt("FuseDuration");
        if (fuseDuration == 0) fuseDuration = 1200;
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putString("LanternMode", mode.name());
        nbt.putBoolean("FlickerOn", flickerOn);
        nbt.putInt("FlickerTimer", flickerTimer);
        nbt.putBoolean("Fused", fused);
        nbt.putInt("FuseTimer", fuseTimer);
        nbt.putInt("FuseDuration", fuseDuration);
    }

    @Nullable
    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt() {
        return createNbt();
    }

    @Override
    public void writeScreenOpeningData(ServerPlayerEntity player, PacketByteBuf buf) {
        buf.writeBlockPos(pos);
    }

    @Override
    public Text getDisplayName() {
        return Text.translatable("gui.lantern-config.title");
    }

    @Nullable
    @Override
    public ScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
        return new LanternScreenHandler(syncId, inv, this);
    }

    public void openScreen(ServerPlayerEntity player) {
        player.openHandledScreen(this);
    }
}
