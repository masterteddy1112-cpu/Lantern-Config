package name.modid.blockentity;

import name.modid.LanternConfig;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlockEntities {

    public static BlockEntityType<LanternBlockEntity> LANTERN_BLOCK_ENTITY;

    public static void register() {
        LANTERN_BLOCK_ENTITY = Registry.register(
            Registries.BLOCK_ENTITY_TYPE,
            new Identifier(LanternConfig.MOD_ID, "lantern"),
            FabricBlockEntityTypeBuilder.create(LanternBlockEntity::new,
                Blocks.LANTERN, Blocks.SOUL_LANTERN).build()
        );
    }
}
