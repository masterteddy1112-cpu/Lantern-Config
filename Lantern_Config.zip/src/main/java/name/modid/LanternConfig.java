package name.modid;

import name.modid.blockentity.LanternBlockEntity;
import name.modid.blockentity.ModBlockEntities;
import name.modid.screen.ModScreenHandlers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LanternConfig implements ModInitializer {
	public static final String MOD_ID = "lantern-config";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModBlockEntities.register();
		ModScreenHandlers.register();
		LOGGER.info("Lantern Modes Mod (lantern-config) initialized.");

		// Server: receive mode change packet from client GUI button click
		ServerPlayNetworking.registerGlobalReceiver(ModPackets.SET_LANTERN_MODE, (server, player, handler, buf, responseSender) -> {
			BlockPos pos = buf.readBlockPos();
			int modeIndex = buf.readInt();
			server.execute(() -> {
				if (!player.isCreative() || !player.hasPermissionLevel(2)) return;
				var be = player.getWorld().getBlockEntity(pos);
				if (be instanceof LanternBlockEntity lanternBE) {
					lanternBE.setMode(LanternMode.fromIndex(modeIndex));
				}
			});
		});

		// Server-side: open GUI when operator right-clicks lantern in creative
		UseBlockCallback.EVENT.register((PlayerEntity player, World world, Hand hand, BlockHitResult hit) -> {
			if (world.isClient()) return ActionResult.PASS;

			var state = world.getBlockState(hit.getBlockPos());
			boolean isLantern = state.isOf(Blocks.LANTERN) || state.isOf(Blocks.SOUL_LANTERN);

			if (!isLantern) return ActionResult.PASS;
			if (!player.isCreative()) return ActionResult.PASS;
			if (!player.hasPermissionLevel(2)) return ActionResult.PASS;

			var be = world.getBlockEntity(hit.getBlockPos());
			if (be instanceof LanternBlockEntity lanternBE) {
				if (player instanceof ServerPlayerEntity serverPlayer) {
					lanternBE.openScreen(serverPlayer);
					return ActionResult.SUCCESS;
				}
			}
			return ActionResult.PASS;
		});
	}
}
