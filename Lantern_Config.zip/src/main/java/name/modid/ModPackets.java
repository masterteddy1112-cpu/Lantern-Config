package name.modid;

import net.minecraft.util.Identifier;

public class ModPackets {
    public static final Identifier SET_LANTERN_MODE = new Identifier(LanternConfig.MOD_ID, "set_lantern_mode");
}
