package name.modid.screen;

import name.modid.LanternMode;
import name.modid.blockentity.LanternBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.util.math.BlockPos;

public class LanternScreenHandler extends ScreenHandler {

    private final LanternBlockEntity blockEntity;

    // Server-side constructor
    public LanternScreenHandler(int syncId, PlayerInventory inv, LanternBlockEntity be) {
        super(ModScreenHandlers.LANTERN_SCREEN_HANDLER, syncId);
        this.blockEntity = be;
    }

    // Client-side constructor (called via ExtendedScreenHandlerFactory)
    public LanternScreenHandler(int syncId, PlayerInventory inv, PacketByteBuf buf) {
        super(ModScreenHandlers.LANTERN_SCREEN_HANDLER, syncId);
        BlockPos pos = buf.readBlockPos();
        this.blockEntity = (LanternBlockEntity) inv.player.getWorld().getBlockEntity(pos);
    }

    public LanternBlockEntity getBlockEntity() {
        return blockEntity;
    }

    public void setModeFromClient(LanternMode mode) {
        if (blockEntity != null) {
            blockEntity.setMode(mode);
        }
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return player.isCreative() && player.hasPermissionLevel(2);
    }
}
