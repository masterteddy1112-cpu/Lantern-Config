package name.modid.screen;

import name.modid.LanternConfig;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class ModScreenHandlers {

    public static ScreenHandlerType<LanternScreenHandler> LANTERN_SCREEN_HANDLER;

    public static void register() {
        LANTERN_SCREEN_HANDLER = Registry.register(
            Registries.SCREEN_HANDLER,
            new Identifier(LanternConfig.MOD_ID, "lantern_screen"),
            new ExtendedScreenHandlerType<>(LanternScreenHandler::new)
        );
    }
}
