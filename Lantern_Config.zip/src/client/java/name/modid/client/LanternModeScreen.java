package name.modid.client;

import name.modid.LanternMode;
import name.modid.ModPackets;
import name.modid.screen.LanternScreenHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

@Environment(EnvType.CLIENT)
public class LanternModeScreen extends HandledScreen<LanternScreenHandler> {

    private static final int GUI_WIDTH = 200;
    private static final int GUI_HEIGHT = 160;

    private static final LanternMode[] MODES = LanternMode.values();

    private static final String[] MODE_NAMES = {
        "Regular",
        "Random Flicker",
        "Fused"
    };

    private static final String[] MODE_DESCRIPTIONS = {
        "§7The lantern burns steadily.\nA reliable, constant light source\nthat never changes intensity.\nPerfect for a stable environment.",
        "§7The lantern flickers unpredictably.\nLight stutters and dims at random\nintervals, casting eerie shadows.\nIdeal for abandoned, spooky tunnels.",
        "§7The lantern is slowly dying.\nOnce placed, it will burn out\nafter a random amount of time\n(30 seconds to 3 minutes). Gone forever."
    };

    private LanternMode currentMode;
    private final BlockPos blockPos;

    public LanternModeScreen(LanternScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
        this.backgroundWidth = GUI_WIDTH;
        this.backgroundHeight = GUI_HEIGHT;
        this.currentMode = handler.getBlockEntity() != null
            ? handler.getBlockEntity().getMode()
            : LanternMode.REGULAR;
        this.blockPos = handler.getBlockEntity() != null
            ? handler.getBlockEntity().getPos()
            : BlockPos.ORIGIN;
    }

    @Override
    protected void init() {
        super.init();
        int startX = (width - GUI_WIDTH) / 2;
        int startY = (height - GUI_HEIGHT) / 2;

        int buttonW = 160;
        int buttonH = 24;
        int buttonX = startX + (GUI_WIDTH - buttonW) / 2;

        for (int i = 0; i < MODES.length; i++) {
            final int modeIndex = i;
            final LanternMode mode = MODES[i];
            int buttonY = startY + 36 + i * 32;

            Text tooltip = Text.literal(MODE_DESCRIPTIONS[i]);

            ButtonWidget btn = ButtonWidget.builder(
                Text.literal(MODE_NAMES[i]),
                button -> sendModePacket(modeIndex)
            )
            .dimensions(buttonX, buttonY, buttonW, buttonH)
            .tooltip(Tooltip.of(tooltip))
            .build();

            if (mode == currentMode) {
                btn.setMessage(Text.literal("✔ " + MODE_NAMES[i]).styled(s -> s.withColor(0xFFD700)));
            }

            addDrawableChild(btn);
        }
    }

    private void sendModePacket(int modeIndex) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBlockPos(blockPos);
        buf.writeInt(modeIndex);
        ClientPlayNetworking.send(ModPackets.SET_LANTERN_MODE, buf);
        currentMode = LanternMode.fromIndex(modeIndex);
        clearChildren();
        init();
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        int x = (width - GUI_WIDTH) / 2;
        int y = (height - GUI_HEIGHT) / 2;

        context.fill(x, y, x + GUI_WIDTH, y + GUI_HEIGHT, 0xE8101010);
        context.fill(x, y, x + GUI_WIDTH, y + 1, 0xFF5A4A2A);
        context.fill(x, y + GUI_HEIGHT - 1, x + GUI_WIDTH, y + GUI_HEIGHT, 0xFF5A4A2A);
        context.fill(x, y, x + 1, y + GUI_HEIGHT, 0xFF5A4A2A);
        context.fill(x + GUI_WIDTH - 1, y, x + GUI_WIDTH, y + GUI_HEIGHT, 0xFF5A4A2A);
        context.fill(x, y, x + GUI_WIDTH, y + 26, 0xE0201A10);
        context.fill(x, y + 26, x + GUI_WIDTH, y + 27, 0xFF5A4A2A);
    }

    @Override
    protected void drawForeground(DrawContext context, int mouseX, int mouseY) {
        int titleX = (GUI_WIDTH - textRenderer.getWidth(title)) / 2;
        context.drawText(textRenderer, title, titleX, 8, 0xFFD700, true);

        String label = "Choose Mode:";
        context.drawText(textRenderer, label, (GUI_WIDTH - textRenderer.getWidth(label)) / 2, 28, 0xAA8866, false);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        drawMouseoverTooltip(context, mouseX, mouseY);
    }

    @Override
    protected void init(int x, int y) {}
}
